import { doesNotMatch } from 'assert';
import fs from 'fs';
import { spine } from '../lib/spine-webgl';

describe ('index', function () {
    this.timeout(5000);

    it ('should test spine', (done) => {
        done();
    });
});
